<?php include("../../templates/_header.inc.php"); ?>

<div class="span10">
	<?php include("templates/_video.inc.php"); ?>
</div>

<div class="span4">
	<?php include("../../templates/_about.inc.php"); ?>
	<?php include("../../templates/_moreinfo.inc.php"); ?>
	<?php include("../../templates/_credits.inc.php"); ?>
	<?php include("../../templates/_socialmedia.inc.php"); ?>
	<?php include("../../templates/_archive.inc.php"); ?>
</div>

<div id="forkme">
	<a href="https://github.com/dmolsen/Detector"><img src="/images/ForkMe_Wht.png" width="141" height="141" alt="Fork Me on GitHub" /></a>
</div>

<?php include("../../templates/_footer.inc.php"); ?>