<?php include("../../templates/_header.inc.php"); ?>

<div class="span10">
	<?php include("templates/_video.inc.php"); ?>
	<?php include("../../templates/_moreinfo.inc.php"); ?>
	<?php include("../../templates/_credits.inc.php"); ?>
</div>

<?php include("../../templates/_footer.inc.php"); ?>