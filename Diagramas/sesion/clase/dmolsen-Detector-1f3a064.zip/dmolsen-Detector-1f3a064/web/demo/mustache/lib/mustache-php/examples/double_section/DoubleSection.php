<?php

class DoubleSection extends Mustache {
	public function t() {
		return true;
	}

	public $two = "second";
}