<?php

class Unescaped extends Mustache {
	public $title = "Bear > Shark";
}