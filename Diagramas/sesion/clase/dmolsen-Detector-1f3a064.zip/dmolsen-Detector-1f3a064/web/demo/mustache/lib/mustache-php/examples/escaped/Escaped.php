<?php

class Escaped extends Mustache {
	public $title = '"Bear" > "Shark"';
}