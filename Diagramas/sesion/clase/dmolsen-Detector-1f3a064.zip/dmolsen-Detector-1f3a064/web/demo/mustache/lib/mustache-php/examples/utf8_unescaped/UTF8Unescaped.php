<?php

class UTF8 extends Mustache {
	public $test = '中文又来啦';
}