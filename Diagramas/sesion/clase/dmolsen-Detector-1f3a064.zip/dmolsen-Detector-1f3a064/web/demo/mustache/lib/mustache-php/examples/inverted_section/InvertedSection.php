<?php

class InvertedSection extends Mustache {
	public $repo = array();
}