<?php

class UTF8Unescaped extends Mustache {
	public $test = '中文又来啦';
}