<?php include("templates/_header.inc.php"); ?>

<div class="span10">
	<?php include("templates/_about.inc.php"); ?>
	<?php include("templates/_profileinfo.inc.php"); ?>
	<?php include("templates/_browserprofile.inc.php"); ?>
	<?php include("templates/_featureprofile.inc.php"); ?>
	<?php include("templates/_moreinfo.inc.php"); ?>
	<?php include("templates/_credits.inc.php"); ?>
</div>

<?php include("templates/_footer.inc.php"); ?>