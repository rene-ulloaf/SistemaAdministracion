<h3>Thank You</h3>
<p>
	Thank you for the feedback. It is much appreciated! You can always go back to <a href="/">Detector's main page</a>.
</p>