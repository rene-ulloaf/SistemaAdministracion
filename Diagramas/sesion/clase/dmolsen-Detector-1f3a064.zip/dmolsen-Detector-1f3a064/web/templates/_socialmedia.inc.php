<h3>Share This</h3>

<div style="margin-bottom: 7px">
	<a href="https://twitter.com/share" class="twitter-share-button" data-url="http://detector.dmolsen.com/">Tweet</a>
	<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
</div>

<div style="margin-bottom: 9px" class="span1">
	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1&appId=121664694538359";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>
	<div class="fb-like" data-href="http://detector.dmolsen.com" data-send="false" data-layout="button_count" data-width="100" data-show-faces="false" data-action="like"></div>
</div>

<div style="margin-bottom: 7px">
	<!-- Place this tag where you want the +1 button to render -->
	<g:plusone size="medium"></g:plusone>

	<!-- Place this render call where appropriate -->
	<script type="text/javascript">
	  (function() {
	    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
	    po.src = 'https://apis.google.com/js/plusone.js';
	    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
	  })();
	</script>
</div>