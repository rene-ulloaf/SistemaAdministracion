<!-- gets populated on the server -->

<!-- i really like gaug.es real-time analytics. check out http://get.gaug.es/ -->