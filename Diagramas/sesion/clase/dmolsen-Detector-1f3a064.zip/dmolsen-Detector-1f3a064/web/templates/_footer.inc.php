        </div>
      </div>

      <footer>
        <p>&copy; <a href="http://dmolsen.com/">Dave Olsen</a> 2012 | Design based on <a href="http://twitter.github.com/bootstrap/">Bootstrap</a></p>
      </footer>

    </div> <!-- /container -->
	<?php include($_SERVER['DOCUMENT_ROOT']."/templates/_gauges.inc.php"); ?>
	<?php include($_SERVER['DOCUMENT_ROOT']."/templates/_googleanalytics.inc.php"); ?>
  </body>
</html>