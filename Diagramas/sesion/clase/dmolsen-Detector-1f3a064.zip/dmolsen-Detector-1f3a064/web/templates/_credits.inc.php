<h3>Credits</h3>
			<p>
				Detector is based on <a href="http://www.modernizr.com/">Modernizr</a>, <a href="https://github.com/jamesgpearce/modernizr-server">modernizr-server</a>, and the browser-detection library <a href="https://github.com/dmolsen/ua-parser-php">ua-parser-php</a>.
				It also benefits from a healthy dose of inspiration from <a href="http://yiibu.com/">Yiibu's</a> <a href="https://github.com/yiibu/profile">Profile</a>. 
			</p>